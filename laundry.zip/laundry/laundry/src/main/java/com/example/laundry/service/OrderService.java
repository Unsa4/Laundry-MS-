package com.example.laundry.service;

import com.example.laundry.model.Order;
import com.example.laundry.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

@Service
public class OrderService {

    private final OrderRepository OrderRepository;

    @Autowired
    public OrderService(OrderRepository OrderRepository) {
        this.OrderRepository = OrderRepository;
    }

    public List<Order> getAllOrders() {
        return OrderRepository.findAll();
    }

    public Optional<Order> getOrderById(String id) {
        return OrderRepository.findById(id);
    }

    public Order saveOrder(Order Order) {
        return OrderRepository.save(Order);
    }

    public void deleteOrder(String id) {
        OrderRepository.deleteById(id);
    }

    public Order updateOrder(String id, @Valid Order OrderDetails) {
        OrderDetails.setOrderId(Long.valueOf(id));
        return OrderRepository.save(OrderDetails);
    }
}
