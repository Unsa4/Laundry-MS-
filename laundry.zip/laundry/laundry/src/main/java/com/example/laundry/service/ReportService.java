package com.example.laundry.service;

import com.example.laundry.model.Report;
import com.example.laundry.repository.ReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

@Service
public class ReportService {

    private final ReportRepository ReportRepository;

    @Autowired
    public ReportService(ReportRepository ReportRepository) {
        this.ReportRepository = ReportRepository;
    }

    public List<Report> getAllReports() {
        return ReportRepository.findAll();
    }

    public Optional<Report> getReportById(String id) {
        return ReportRepository.findById(id);
    }

    public Report saveReport(Report Report) {
        return ReportRepository.save(Report);
    }

    public void deleteReport(String id) {
        ReportRepository.deleteById(id);
    }

    public Report updateReport(String id, @Valid Report ReportDetails) {
        ReportDetails.setReportId(Long.valueOf(id));
        return ReportRepository.save(ReportDetails);
    }
}
