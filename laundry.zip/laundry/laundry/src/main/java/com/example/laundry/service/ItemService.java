package com.example.laundry.service;

import com.example.laundry.model.Item;
import com.example.laundry.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@Service
public class ItemService {

    private final ItemRepository ItemRepository;

    @Autowired
    public ItemService(ItemRepository ItemRepository) {
        this.ItemRepository = ItemRepository;
    }

    public List<Item> getAllItems() {
        return ItemRepository.findAll();
    }

    public Optional<Item> getItemById(String id) {
        return ItemRepository.findById(id);
    }

    public Item saveItem(Item Item) {
        return ItemRepository.save(Item);
    }

    public void deleteItem(String id) {
        ItemRepository.deleteById(id);
    }

    public Item updateItem(String id,@Valid Item ItemDetails) {
        ItemDetails.setItemId(id);
        return ItemRepository.save(ItemDetails);
    }
}
