package com.example.laundry.service;

import com.example.laundry.model.Portfolio;
import com.example.laundry.repository.PortfolioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

@Service
public class PortfolioService {

    private final PortfolioRepository PortfolioRepository;

    @Autowired
    public PortfolioService(PortfolioRepository PortfolioRepository) {
        this.PortfolioRepository = PortfolioRepository;
    }

    public List<Portfolio> getAllPortfolios() {
        return PortfolioRepository.findAll();
    }

    public Optional<Portfolio> getPortfolioById(String id) {
        return PortfolioRepository.findById(id);
    }

    public Portfolio savePortfolio(Portfolio Portfolio) {
        return PortfolioRepository.save(Portfolio);
    }

    public void deletePortfolio(String id) {
        PortfolioRepository.deleteById(id);
    }

    public Portfolio updatePortfolio(String id, @Valid Portfolio PortfolioDetails) {
        PortfolioDetails.setPortfolioId(id);
        return PortfolioRepository.save(PortfolioDetails);
    }
}
