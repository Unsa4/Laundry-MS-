package com.example.laundry.service;

import com.example.laundry.model.Customer;
import com.example.laundry.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    private final CustomerRepository CustomerRepository;

    @Autowired
    public CustomerService(CustomerRepository CustomerRepository) {
        this.CustomerRepository = CustomerRepository;
    }

    public List<Customer> getAllCustomers() {
        return CustomerRepository.findAll();
    }

    public Optional<Customer> getCustomerById(String id) {
        return CustomerRepository.findById(id);
    }

    public Customer saveCustomer(Customer Customer) {
        return CustomerRepository.save(Customer);
    }

    public void deleteCustomer(String id) {
        CustomerRepository.deleteById(id);
    }

    public Customer updateCustomer(String id, @Valid Customer CustomerDetails) {
        CustomerDetails.setCustomerId(String.valueOf(Long.valueOf(id)));
        return CustomerRepository.save(CustomerDetails);
    }
}
