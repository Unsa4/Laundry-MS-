package com.example.laundry.service;

import com.example.laundry.model.Services;
import com.example.laundry.repository.ServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

@Service
public class ServiceService {

    private final ServiceRepository ServiceRepository;

    @Autowired
    public ServiceService(ServiceRepository ServiceRepository) {
        this.ServiceRepository = ServiceRepository;
    }

    public List<Services> getAllServices() {
        return ServiceRepository.findAll();
    }

    public Optional<Services> getServiceById(String id) {
        return ServiceRepository.findById(id);
    }

    public Service saveService(Services Service) {
        return (org.springframework.stereotype.Service) ServiceRepository.save(Service);
    }

    public void deleteService(String id) {
        ServiceRepository.deleteById(id);
    }

    public Service updateService(String id,@Valid Services ServiceDetails) {
        ServiceDetails.setServiceId(Long.valueOf(id));
        return (Service) ServiceRepository.save(ServiceDetails);
    }

    public Optional<Services> getServicesById(String valueOf) {
        return Optional.empty();
    }
}
