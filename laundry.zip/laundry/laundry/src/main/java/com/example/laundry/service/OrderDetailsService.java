package com.example.laundry.service;

import com.example.laundry.model.OrderDetails;
import com.example.laundry.repository.OrderDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

@Service
public class OrderDetailsService {

    private final OrderDetailsRepository OrderDetailsRepository;

    @Autowired
    public OrderDetailsService(OrderDetailsRepository OrderDetailsRepository) {
        this.OrderDetailsRepository = OrderDetailsRepository;
    }

    public List<OrderDetails> getAllOrderDetails() {
        return OrderDetailsRepository.findAll();
    }

    public Optional<OrderDetails> getOrderDetailsById(String id) {
        return OrderDetailsRepository.findById(id);
    }

    public OrderDetails saveOrderDetails(OrderDetails OrderDetails) {
        return OrderDetailsRepository.save(OrderDetails);
    }

    public void deleteOrderDetails(String id) {
        OrderDetailsRepository.deleteById(id);
    }

    public OrderDetails updateOrderDetails(String id,@Valid OrderDetails OrderDetailsDetails) {
        OrderDetailsDetails.setOrderDetailsId(Long.valueOf(id));
        return OrderDetailsRepository.save(OrderDetailsDetails);
    }

}
