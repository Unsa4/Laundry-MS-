package com.example.laundry.service;

import com.example.laundry.model.Payment;
import com.example.laundry.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

@Service
public class PaymentService {

    private final PaymentRepository PaymentRepository;

    @Autowired
    public PaymentService(PaymentRepository PaymentRepository) {
        this.PaymentRepository = PaymentRepository;
    }

    public List<Payment> getAllPayments() {
        return PaymentRepository.findAll();
    }

    public Optional<Payment> getPaymentById(String id) {
        return PaymentRepository.findById(id);
    }

    public Payment savePayment(Payment Payment) {
        return PaymentRepository.save(Payment);
    }

    public void deletePayment(String id) {
        PaymentRepository.deleteById(id);
    }

    public Payment updatePayment(String id, @Valid Payment PaymentDetails) {
        PaymentDetails.setPaymentId(Long.valueOf(id));
        return PaymentRepository.save(PaymentDetails);
    }
}
