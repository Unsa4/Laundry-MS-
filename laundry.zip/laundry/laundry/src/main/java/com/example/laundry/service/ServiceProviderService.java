package com.example.laundry.service;

import com.example.laundry.model.ServiceProvider;
import com.example.laundry.repository.ServiceProviderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

@Service
public class ServiceProviderService {

    private final ServiceProviderRepository ServiceProviderRepository;

    @Autowired
    public ServiceProviderService(ServiceProviderRepository ServiceProviderRepository) {
        this.ServiceProviderRepository = ServiceProviderRepository;
    }

    public List<ServiceProvider> getAllServiceProviders() {
        return ServiceProviderRepository.findAll();
    }

    public Optional<ServiceProvider> getServiceProviderById(String id) {
        return ServiceProviderRepository.findById(id);
    }

    public ServiceProvider saveServiceProvider(ServiceProvider ServiceProvider) {
        return ServiceProviderRepository.save(ServiceProvider);
    }

    public void deleteServiceProvider(String id) {
        ServiceProviderRepository.deleteById(id);
    }

    public ServiceProvider updateServiceProvider(String id, @Valid ServiceProvider ServiceProviderDetails) {
        ServiceProviderDetails.setServiceProviderId(Long.valueOf(id));
        return ServiceProviderRepository.save(ServiceProviderDetails);
    }
}
