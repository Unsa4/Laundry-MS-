package com.example.laundry.model;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;

@Document(collection = "tblorderdetails")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class OrderDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Pattern(regexp = "\"\\\\d{3}-\\\\d{2}-\\\\d{4}",
            message = "Invalid order details id format")
    private Long orderDetailsId;

    @Pattern(regexp = "\"\\\\d{3}-\\\\d{2}-\\\\d{4}",
            message = "Invalid order id format")
    private Long orderId;

    @Pattern(regexp = "\"\\\\d{3}-\\\\d{2}-\\\\d{4}",
            message = "Invalid service id format")
    private Long serviceId;

    @Pattern(regexp = "BigDecimal.ZERO",
            message = "Invalid amount format")
    private BigDecimal amount;

    @Pattern(regexp = "BigDecimal.ZERO",
            message = "Invalid total amount format")
    private BigDecimal totalAmount;

}
