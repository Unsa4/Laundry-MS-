package com.example.laundry.service;

import com.example.laundry.model.Rating;
import com.example.laundry.repository.RatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

@Service
public class RatingService {

    private final RatingRepository RatingRepository;

    @Autowired
    public RatingService(RatingRepository RatingRepository) {
        this.RatingRepository = RatingRepository;
    }

    public List<Rating> getAllRatings() {
        return RatingRepository.findAll();
    }

    public Optional<Rating> getRatingById(String id) {
        return RatingRepository.findById(id);
    }

    public Rating saveRating(Rating Rating) {
        return RatingRepository.save(Rating);
    }

    public void deleteRating(String id) {
        RatingRepository.deleteById(id);
    }

    public Rating updateRating(String id, @Valid Rating RatingDetails) {
        RatingDetails.setRatingId(Long.valueOf(id));
        return RatingRepository.save(RatingDetails);
    }
}
