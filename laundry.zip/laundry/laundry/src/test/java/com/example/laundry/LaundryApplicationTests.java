package com.example.laundry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaundryApplicationTests {

	@Test
	void contextLoads() {
	}

}
